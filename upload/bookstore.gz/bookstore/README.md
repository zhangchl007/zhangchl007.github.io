# bookstore
Source code for my Tutorial "Test a Node RESTful API with Mocha and Chai"

# test
* `sleep 20s && pybot -d report -v BROWSER:phantomjs -v  SERVER:${SERVER}:7373 login_tests`
